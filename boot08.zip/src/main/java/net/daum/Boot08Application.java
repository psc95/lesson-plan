package net.daum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot08Application {

	public static void main(String[] args) {
		SpringApplication.run(Boot08Application.class, args);
	}

}
