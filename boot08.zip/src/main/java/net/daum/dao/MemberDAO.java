package net.daum.dao;

import net.daum.vo.Member;

public interface MemberDAO {

	Member idCheck(String id);
	void insertMember(Member m);

}
