package net.daum.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import net.daum.vo.Member;

@Repository
public class MemberDAOImpl implements MemberDAO{

	@Autowired
	private MemberRepository memberRepo;

	@Override
	public Member idCheck(String id) {
		
    	System.out.println(" \n 아이디 중복 검색(JPA) =================>");        
		Optional<Member> result = this.memberRepo.findById(id);
	    Member member;
	    if(result.isPresent()){//아이디에 해당하는 회원 정보가 있다면 참
	        member = result.get();//MemberVO 엔티티 타입 객체를 구함	        
	    }else {//회원정보가 없다면
	    	member=null;//null을 저장한 후 반환
	    }
		return member;
	}//아이디 중복 검색

	@Override
	public void insertMember(Member m) {		
		System.out.println("\n 회원저장(JPA) ==============================>");		
		this.memberRepo.save(m);
	}//회원저장	
}
