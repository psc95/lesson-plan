package net.daum.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import net.daum.vo.Member;

public interface MemberRepository extends JpaRepository<Member,String> {

	
}
