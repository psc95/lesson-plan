package net.daum.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.daum.dao.MemberDAO;
import net.daum.vo.Member;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberDAO memberDao;
	
	@Override
	public Member idCheck(String id) {
		return this.memberDao.idCheck(id);
	}

	@Override
	public void insertMember(Member m) {
		this.memberDao.insertMember(m);		
	}
}
