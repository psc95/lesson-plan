package net.daum.service;

import net.daum.vo.Member;

public interface MemberService {

	Member idCheck(String id);
	void insertMember(Member m);

}
