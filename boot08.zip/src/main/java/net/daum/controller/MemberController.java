package net.daum.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import net.daum.service.MemberService;
import net.daum.vo.Member;

@Controller
public class MemberController {//사용자 회원관리 컨트롤러

	@Autowired
	private MemberService memberService;
	
	@Autowired 
	private PasswordEncoder passwordEncoder;

	//회원가입 폼
	@RequestMapping("/member_join")
	public ModelAndView member_join() {

		ModelAndView jm=new ModelAndView();

		jm.setViewName("member/member_Join");//뷰페이지 경로(뷰리졸브 경로)=> /WEB-INF/views/member/
		//member_Join.jsp
		return jm;
	}//member_join()


	//아이디 중복 검색	
	@RequestMapping("/member_idcheck")
	public ModelAndView member_idcheck(String id,HttpServletResponse response)
			throws Exception{
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();

		//System.out.println("id:"+id);
		Member db_id=this.memberService.idCheck(id);//아이디에 해당하는 회원정보를  DB로 부터 검색

		int re=-1;//중복 아이디가 없을때 반환값

		if(db_id != null) { //중복 아이디가 있는 경우
			re=1;			
		}
		out.println(re);//값 반환
		
		return null;
	}//member_idcheck()


	//회원저장
	@RequestMapping("/member_join_ok")
	public ModelAndView member_join_ok(Member m) {
		/* member_join.jsp의 네임 피라미터 이름과 빈클래스의 변수명이 같으면 MemberVO m에서 m에 가입폼에서 입력한 정보가
		 * 저장되어 있다.
		 */
		System.out.println("아이디:"+m.getUid2());
		System.out.println("비번:"+m.getUpw());
		System.out.println("회원이름:"+m.getUname());
		System.out.println("권한 목록 :"+m.getRoles().toString());
		
		m.setUpw(passwordEncoder.encode(m.getUpw()));//비번 암호화
		this.memberService.insertMember(m);//회원저장
	
		return new ModelAndView("redirect:/login");
		
	}//member_join_ok()
}
































