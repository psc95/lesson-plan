SELECT uid2 username, upw password,uname FROM tbl_members2 WHERE uid2='user88';

SELECT member uid2, role_name role FROM tbl_member_roles WHERE member ='user88';

select * from tbl_member_roles order by member;
select * from tbl_members2 order by uid2 asc;

delete from tbl_member_roles where member='hhhhh';
delete from tbl_members2 where uid2='hhhhh';

commit;

drop table tbl_member_roles;
drop table tbl_members2;

drop sequence member_no_seq;

alter sequence member3_no_seq
nocache; --nocache로 수정

--스프링 시큐리티 자동로그인 정보를 유지하는 테이블
create table persistent_logins(
  username varchar2(64) not null --회원아이디
  ,series varchar2(64) primary key --비번
  ,token varchar2(64) not null --토큰정보
  ,last_used timestamp not null --로그인한 날짜 시간
);

select * from persistent_logins;

  ALTER TABLE tbl_members3 MODIFY (mem_delcont VARCHAR2(4000));
