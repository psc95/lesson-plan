package net.daum;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.junit4.SpringRunner;

import lombok.extern.java.Log;
import net.daum.dao.MemberRepository;
import net.daum.vo.Member;
import net.daum.vo.MemberRole;

@RunWith(SpringRunner.class)
@SpringBootTest
@Log
@Commit
public class MemberTests {

	@Autowired
	private MemberRepository memberRepo;	
		
	@Autowired //setter() 메서드 DI의존성 주입->자동의존성 주입
	private PasswordEncoder passwordEncoder;	
	
	@Test
	public void testInsert() {

		for (int i = 1; i <= 100; i++) {

			Member member = new Member();
			member.setUid2("user" + i);
			member.setUpw(passwordEncoder.encode("pw"+i));
			member.setUname("사용자" + i);

			MemberRole role = new MemberRole();
			if (i <= 80) {
				role.setRoleName("BASIC");
			} else if (i <= 90) {
				role.setRoleName("MANAGER");
			} else {
				role.setRoleName("ADMIN");
			}
			member.setRoles(Arrays.asList(role));//Arrays.asList()는 자바에서 Array를 List으로 변환=>여기서는 MemberRole 타입을 컬렉션 List 
			//MemberRole 제네릭타입으로 변환

			this.memberRepo.save(member);//회원 저장
		}//for
	}//testInsert()
	
	@Test
	public void testRead() {

		//Optional<Member> result = this.memberRepo.findById("user85");
		//result.ifPresent(member -> log.info("member 회원 정보: "+ member));		
	}//testRead()
}
