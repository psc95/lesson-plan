package net.daum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot09JpaSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Boot09JpaSecurityApplication.class, args);
	}

}
