package net.daum.vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ZipcodeVO2 {

	private String zipcode;//우편번호
	private String addr;//시도 구군 동	
}
