package net.daum.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import net.daum.service.MemberService;
import net.daum.vo.MemberVO;
import net.daum.vo.ZipCodeVO;
import net.daum.vo.ZipcodeVO2;

@Controller
public class MemberController {//사용자 회원관리 컨트롤러

	@Autowired
	private MemberService memberService;

	@Autowired 
	private PasswordEncoder passwordEncoder;

	//회원가입 폼
	@RequestMapping("/member_join")
	public ModelAndView member_join() {

		String[] phone = {"010","011","019"};
		String[] email = {"naver.com","daum.net","nate.com","gmail.com","직접입력"};

		ModelAndView jm=new ModelAndView();

		jm.addObject("phone",phone);
		jm.addObject("email",email);

		jm.setViewName("member/member_Join");//뷰페이지 경로(뷰리졸브 경로)=> /WEB-INF/views/member/
		//member_Join.jsp
		return jm;
	}//member_join()

	//아이디 중복 검색	
	@RequestMapping("/member_idcheck")
	public ModelAndView member_idcheck(String id,HttpServletResponse response)
			throws Exception{
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();

		//System.out.println("id:"+id);
		MemberVO db_id=this.memberService.idCheck(id);//아이디에 해당하는 회원정보를  DB로 부터 검색

		int re=-1;//중복 아이디가 없을때 반환값

		if(db_id != null) { //중복 아이디가 있는 경우
			re=1;			
		}
		out.println(re);//값 반환

		return null;
	}//member_idcheck()	

	//우편주소 검색 공지창
	@RequestMapping("/zip_find")
	public ModelAndView zip_find() {
		ModelAndView zm=new ModelAndView();
		zm.setViewName("member/zip_find");
		return zm;
	}//zip_find()

	//우편주소 검색 결과
	@RequestMapping("/zip_find_ok")
	public ModelAndView zip_find_ok(String dong) {
		List<ZipCodeVO> zlist=this.memberService.zipFind("%"+dong+"%");//%는 검색할 때 사용하는 와일드
		//카드  sql 연산자로 하나이상의 임의의 모르는 문자와 매핑 대응한다.

		List<ZipcodeVO2> zlist2=new ArrayList<>();

		for(ZipCodeVO z:zlist) {
			ZipcodeVO2 z2=new ZipcodeVO2();

			z2.setZipcode(z.getZipcode());//우편번호 저장
			z2.setAddr(z.getSido()+" "+z.getGugun()+" "+z.getGil());//시도 구군 동을 저장

			zlist2.add(z2);//컬렉션에 우편번호와 주소를 추가
		}

		ModelAndView zm=new ModelAndView("member/zip_find");
		zm.addObject("zipcodelist",zlist2);
		zm.addObject("dong",dong);
		return zm;
	}//zip_find_ok()

	//회원저장
	@RequestMapping("/member_join_ok")
	public ModelAndView member_join_ok(MemberVO m) {
		/* member_join.jsp의 네임 피라미터 이름과 빈클래스의 변수명이 같으면 MemberVO m에서 m에 가입폼에서 입력한 정보가
		 * 저장되어 있다.
		 */
		//System.out.println("아이디:"+m.getMem_id());
		//System.out.println("비번:"+m.getMem_pwd());
		//System.out.println("회원이름:"+m.getMem_name());
		System.out.println("권한 목록 :"+m.getRoles().toString());

		m.setMem_pwd(passwordEncoder.encode(m.getMem_pwd()));//비번 암호화
		this.memberService.insertMember(m);//회원저장

		return new ModelAndView("redirect:/login");

	}//member_join_ok()

	//비번찾기 공지창
	@RequestMapping("/pwd_find")
	public ModelAndView pwd_find() {
		return new ModelAndView("member/pwd_find");
	}//pwd_find()

	//비번찾기 결과
	@RequestMapping("/pwd_find_ok") 
	public ModelAndView pwd_find_ok(@RequestParam("pwd_id") String pwd_id,String pwd_name,
			HttpServletResponse response,MemberVO m) throws Exception{
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();

		m.setMem_id(pwd_id); m.setMem_name(pwd_name);
		MemberVO pm=this.memberService.pwdMember(m);//아이디와 회원이름을 기준으로 DB로 부터 회원정보 검색

		if(pm == null) {
			out.println("<script>");
			out.println("alert('회원으로 검색되지 않습니다!\\n 올바른 회원정보를 입력하세요!');");
			out.println("history.back();");
			out.println("</script>");
		}else {
			Random r=new Random();
			int pwd_random=r.nextInt(100000);//0이상 십만 미만 사이의 정수 숫자 난수를 발생
			String ran_pwd=Integer.toString(pwd_random);//임시 정수 비번을 문자열로 변경
			m.setMem_pwd(passwordEncoder.encode(ran_pwd));//임시 비번 암호화

			this.memberService.updatePwd(m);//오라클 DB의 비번을 암호화된 임시비번으로 수정			

			ModelAndView fm=new ModelAndView("member/pwd_find_ok");//생성자 인자값으로 뷰페이지 경로와 파일
			//명 설정
			fm.addObject("pwd_ran",ran_pwd);
			return fm;
		}
		return null;
	}//pwd_find_ok()

	//회원정보 수정폼
	@RequestMapping("/member_edit")
	public ModelAndView member_edit(HttpServletResponse response,HttpSession session)
			throws Exception{
		response.setContentType("text/html;charset=UTF-8");
		String id=(String)session.getAttribute("id");//세션 아이디를 구함.

		if(isLogin(session, response)) {//==true가 생략됨 ->로그인 된 상태
			String[] phone = {"010","011","019"};
			String[] email = {"naver.com","daum.net","nate.com","gmail.com","직접입력"};
			MemberVO em=this.memberService.getMember(id);//아이디에 해당하는 회원정보를 구함		

			ModelAndView m=new ModelAndView();
			m.addObject("em",em);
			m.addObject("phone",phone);
			m.addObject("email",email);
			m.setViewName("member/member_Edit");
			return m;
		}
		return null;
	}//member_edit()

	//정보수정 완료
	@RequestMapping("/member_update_ok")
	public ModelAndView member_update_ok(MemberVO m,HttpServletResponse response,HttpSession
			session) throws Exception{
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();

		String id=(String)session.getAttribute("id");

		if(isLogin(session, response)) {
			m.setMem_id(id);
			m.setMem_pwd(passwordEncoder.encode(m.getMem_pwd()));//정식비번 암호화

			this.memberService.updateMember(m);//정보 수정			

			out.println("<script>");
			out.println("alert('정보 수정했습니다!');");
			out.println("location='member_edit';");
			out.println("</script>");
		}		
		return null;
	}//member_update_ok()

	//반복적인 코드를 하나로 줄이기
	public static boolean isLogin(HttpSession session,HttpServletResponse response)
			throws Exception{
		PrintWriter out=response.getWriter();
		String id=(String)session.getAttribute("id");//세션 아이디를 구함.

		if(id == null) {
			out.println("<script>");
			out.println("alert('다시 로그인 하세요!');");
			out.println("location='login';");
			out.println("</script>");

			return false;
		}
		return true;//로그인 된 경우는  true를 반환
	}//isLogin()
}
































