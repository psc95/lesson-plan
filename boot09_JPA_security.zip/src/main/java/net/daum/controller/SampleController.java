package net.daum.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.java.Log;

@Controller
@Log
public class SampleController {

	@GetMapping("/")
	public String index() {
		
		log.info("index");
		return "index";
	}//index()
	
	@RequestMapping("/guest")
	public void forGuest() {
		
		log.info("guest");
	}//guest
	
	@RequestMapping("/manager")
	public void forManager() {
		
		log.info("manager");
	}//manager
	
	@RequestMapping("/admin")
	public void forAdmin() {

		log.info("admin");
	}//admin
}
