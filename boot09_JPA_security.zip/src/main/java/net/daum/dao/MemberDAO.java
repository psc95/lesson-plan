package net.daum.dao;

import java.util.List;

import net.daum.vo.MemberVO;
import net.daum.vo.ZipCodeVO;

public interface MemberDAO {

	MemberVO idCheck(String id);
	void insertMember(MemberVO m);
	List<ZipCodeVO> zipFind(String dong);
	MemberVO pwdMember(MemberVO m);
	void updatePwd(MemberVO m);
	MemberVO getMember(String id);
	void updateMember(MemberVO m);

}
