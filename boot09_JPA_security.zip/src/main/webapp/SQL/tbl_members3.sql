select * from tbl_members2 order by uid2 asc;

select * from tbl_member_roles3 order by fno asc;

select * from zipcode;

delete from tbl_member_roles3;
delete from tbl_members3;

rollback;

drop table tbl_member_roles3;

drop table tbl_members3;

commit;

select * from persistent_logins;

alter sequence zip_no_seq
nocache; --nocache로 수정